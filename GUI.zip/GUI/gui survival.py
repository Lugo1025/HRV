import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tensorflow as tf
import joblib
import os
import pyhrv.tools as tools
import pyhrv.time_domain as td
import pyhrv.frequency_domain as fd
import pyhrv.nonlinear as nl

MODEL_DIR = "models"

model_options = {
    "Correlation (Top 15)": "Correlation_Top_15",
    "Correlation (Top 5)": "Correlation_Top_5",
    "Random Forest (Top 15)": "Random_Forest_Top_15",
    "Mutual Info (Top 15)": "Mutual_Info_Top_15"
}

logistic_configs = {
    "Correlation (Top 15)": {"intercept": -1.56, "coefficients": [0.9935, -0.8616, -0.3997, 0.4176, 1.3032, 0.6154, -1.0923, -0.7660, 0.0339, 0.5334, -0.3454, 0.2803, -1.2534, -0.0580, -0.0356]},
    "Correlation (Top 5)": {"intercept": -0.98, "coefficients": [0.6911, -0.7299, -0.4806, 0.3434, 0.4582]},
    "Random Forest (Top 15)": {"intercept": -2.13, "coefficients": [-0.8802, 0.0126, -0.1310, 0.5466, 0.7636, -0.3909, 0.5237, -0.0725, -0.0957, 4.2304, -0.0993, -0.2375, 0.2987, -3.9837, 0.2913]},
    "Mutual Info (Top 15)": {"intercept": -4.76, "coefficients": [0.6242, -0.8800, 0.3398, 0.8169, -4.1321, -0.1551, 0.6996, 316.9673, -0.0772, 0.3284, -11.0592, 0.1891, -8.0655, 1.8160, 0.9937]}
}

def load_ann_model(model_key):
    prefix = model_options[model_key]
    model = tf.keras.models.load_model(os.path.join(MODEL_DIR, f"{prefix}_model.h5"))
    scaler = joblib.load(os.path.join(MODEL_DIR, f"{prefix}_scaler.pkl"))
    with open(os.path.join(MODEL_DIR, f"{prefix}_features.txt"), "r") as f:
        features = [line.strip() for line in f.readlines()]
    return model, scaler, features

def predict_ann(file_path, model, scaler, feature_order):
    with open(file_path, "r") as f:
        values = list(map(float, f.read().strip().split()))
    x = np.array(values).reshape(1, -1)
    x_scaled = scaler.transform(x)
    prob = model.predict(x_scaled).ravel()[0]
    label = "Alive (0)" if prob < 0.5 else "Dead (1)"
    return label, prob, values

def predict_logistic(values, model_key):
    config = logistic_configs[model_key]
    intercept = config["intercept"]
    coefs = np.array(config["coefficients"])
    logit = intercept + np.dot(coefs, values)
    prob = 1 / (1 + np.exp(-logit))
    return prob

def analyze_rr_file(rr_path, output_txt):
    df = pd.read_csv(rr_path, sep="\t")
    rr_intervals = df['Pulse Interval (ms)'].values
    rr_intervals = tools.check_input(rr_intervals)
    time_results = td.time_domain(rr_intervals)
    freq_results = fd.welch_psd(rr_intervals)
    nonlinear_results = nl.nonlinear(rr_intervals)

    with open(output_txt, "w") as f:
        f.write("HRV Features Extracted from RR Intervals\n")
        f.write("\nTime Domain:\n")
        for key, value in time_results.items():
            f.write(f"{key}: {value}\n")
        f.write("\nFrequency Domain:\n")
        for key, value in freq_results.items():
            f.write(f"{key}: {value}\n")
        f.write("\nNonlinear Measures:\n")
        for key, value in nonlinear_results.items():
            f.write(f"{key}: {value}\n")

    return df

class ICUApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ICU Survival Prediction GUI")
        self.root.geometry("1000x850")
        self.root.configure(bg="#f2f4f7")

        self.file_path = None
        self.rr_path = None

        tk.Label(root, text="ICU Survival Prediction", font=("Helvetica", 24, "bold"), fg="#003366", bg="#f2f4f7").pack(pady=15)

        form = tk.Frame(root, bg="#f2f4f7")
        form.pack()

        tk.Label(form, text="Patient ID:", bg="#f2f4f7", font=("Helvetica", 12)).grid(row=0, column=0, sticky="e", pady=5)
        self.id_entry = tk.Entry(form, width=30, font=("Helvetica", 12))
        self.id_entry.grid(row=0, column=1, pady=5)

        tk.Label(form, text="Patient Name:", bg="#f2f4f7", font=("Helvetica", 12)).grid(row=1, column=0, sticky="e", pady=5)
        self.name_entry = tk.Entry(form, width=30, font=("Helvetica", 12))
        self.name_entry.grid(row=1, column=1, pady=5)

        tk.Label(form, text="Model:", bg="#f2f4f7", font=("Helvetica", 12)).grid(row=2, column=0, sticky="e", pady=5)
        self.model_var = tk.StringVar()
        model_dropdown = ttk.Combobox(form, textvariable=self.model_var, values=list(model_options.keys()), state="readonly", width=28)
        model_dropdown.grid(row=2, column=1, pady=5)
        model_dropdown.set("Correlation (Top 15)")

        tk.Button(root, text="Upload Clinical File (.txt)", command=self.upload_clinical_file, bg="#003366", fg="white", font=("Helvetica", 12)).pack(pady=8)
        tk.Button(root, text="Upload RR File (.txt)", command=self.upload_rr_file, bg="#005580", fg="white", font=("Helvetica", 12)).pack(pady=8)
        tk.Button(root, text="Analyze", command=self.analyze, bg="#009966", fg="white", font=("Helvetica", 14, "bold")).pack(pady=10)

        self.result_label = tk.Label(root, text="", font=("Helvetica", 14), bg="#f2f4f7", fg="darkred")
        self.result_label.pack(pady=10)

        self.log_label = tk.Label(root, text="", font=("Helvetica", 14), bg="#f2f4f7", fg="darkblue")
        self.log_label.pack(pady=10)

        self.canvas = None

    def upload_clinical_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        messagebox.showinfo("File Upload", "Clinical variable file loaded.")

    def upload_rr_file(self):
        self.rr_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if self.rr_path:
            patient_id = self.id_entry.get().strip()
            patient_name = self.name_entry.get().strip().replace(" ", "_")
            rr_out = f"{patient_id}_{patient_name}_rr.txt"
            df_rr = analyze_rr_file(self.rr_path, rr_out)

            fig, ax = plt.subplots(figsize=(7, 3))
            ax.plot(df_rr['Time (s)'], df_rr['Pulse Interval (ms)'], linewidth=1.2)
            ax.set_title("RR Interval Time Series")
            ax.set_xlabel("Time (s)")
            ax.set_ylabel("Pulse Interval (ms)")
            fig.tight_layout()

            if self.canvas:
                self.canvas.get_tk_widget().destroy()
            self.canvas = FigureCanvasTkAgg(fig, master=self.root)
            self.canvas.draw()
            self.canvas.get_tk_widget().pack(pady=10)

            messagebox.showinfo("RR Analysis", f"RR interval analysis saved to:\n{rr_out}")

    def analyze(self):
        try:
            model_key = self.model_var.get()
            patient_name = self.name_entry.get().strip().replace(" ", "_")
            patient_id = self.id_entry.get().strip()

            if not all([model_key, patient_name, patient_id, self.file_path]):
                raise Exception("Missing patient info or clinical variable file.")

            model, scaler, features = load_ann_model(model_key)
            label, ann_prob, values = predict_ann(self.file_path, model, scaler, features)
            log_prob = predict_logistic(values, model_key)

            self.result_label.config(text=f"ANN Prediction: {label}", fg="red")
            self.log_label.config(text=f"Logistic Estimated Survival Probability: {(1 - ann_prob) * 100:.2f}%", fg="blue")

            result_path = f"{patient_id}_{patient_name}_results.txt"
            with open(result_path, "w") as f:
                f.write(f"Model: {model_key}\n")
                f.write(f"ANN Prediction: {label}\n")
                f.write(f"Survival Probability: {(1 - ann_prob) * 100:.2f}%\n")
                #f.write(f"Logistic Estimated Survival Probability: {log_prob * 100:.2f}%\n")
                f.write("\nClinical Input Variables:\n")
                for name, val in zip(features, values):
                    f.write(f"{name}: {val}\n")
            messagebox.showinfo("Saved", f"Prediction results saved to {result_path}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = ICUApp(root)
    root.mainloop()
