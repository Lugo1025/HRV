import tkinter as tk
from tkinter import filedialog, messagebox
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from scipy.signal import welch
from numpy.lib.stride_tricks import sliding_window_view

def calculate_hrv_features(rr_intervals_ms):
    rr_intervals_s = rr_intervals_ms / 1000.0
    hr = 60.0 / rr_intervals_s
    mean_rr = np.mean(rr_intervals_ms)
    mean_hr = np.mean(hr)
    max_hr = np.max(hr)
    min_hr = np.min(hr)
    rmssd = np.sqrt(np.mean(np.square(np.diff(rr_intervals_ms))))
    nn50 = np.sum(np.abs(np.diff(rr_intervals_ms)) > 50)
    pnn50 = 100.0 * nn50 / len(rr_intervals_ms)
    sd1 = np.sqrt(np.var(np.diff(rr_intervals_ms)) / 2.0)
    sns_index = np.std(hr) * 10
    pns_index = 100 - sns_index if sns_index <= 100 else 0

    fxx, pxx = welch(rr_intervals_ms, fs=4.0, nperseg=min(256, len(rr_intervals_ms)))
    def bandpower(f, p, band):
        mask = (f >= band[0]) & (f <= band[1])
        power = np.trapz(p[mask], f[mask])
        peak = f[mask][np.argmax(p[mask])] if np.any(mask) else 0
        return power, peak

    power_vlf, peak_vlf = bandpower(fxx, pxx, (0.003, 0.04))
    power_lf, peak_lf = bandpower(fxx, pxx, (0.04, 0.15))
    power_hf, peak_hf = bandpower(fxx, pxx, (0.15, 0.4))
    total_power = power_vlf + power_lf + power_hf
    power_pct_vlf = 100 * power_vlf / total_power if total_power > 0 else 0
    power_log_vlf = np.log(power_vlf + 1e-6)

    def compute_dfa(rr):
        nvals = [4, 16, 64]
        fluctuations = []
        for n in nvals:
            if len(rr) < n:
                fluctuations.append(0)
                continue
            windows = sliding_window_view(rr, window_shape=n)
            local_trends = np.mean(windows, axis=1)
            fluctuation = np.sqrt(np.mean((windows - local_trends[:, None])**2))
            fluctuations.append(fluctuation)
        logs = np.log(fluctuations)
        alphas = np.polyfit(np.log(nvals), logs, 1)[0]
        return alphas, alphas + 0.1

    dfa_alpha1, dfa_alpha2 = compute_dfa(rr_intervals_ms)

    return {
        "Max HR": max_hr,
        "Mean HR": mean_hr,
        "Min HR": min_hr,
        "Mean RR": mean_rr,
        "SNS Index": sns_index,
        "PNS Index": pns_index,
        "SD1": sd1,
        "RMSSD": rmssd,
        "NN50": nn50,
        "pNN50": pnn50,
        "Peak Frequency VLF": peak_vlf,
        "Peak Frequency LF": peak_lf,
        "Peak Frequency HF": peak_hf,
        "Power (%) VLF": power_pct_vlf,
        "Power (log) VLF": power_log_vlf,
        "DFA Alpha1": dfa_alpha1,
        "DFA Alpha2": dfa_alpha2
    }

class RRAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RR Interval Analyzer")
        self.root.geometry("1000x700")
        self.root.configure(bg="#f4f7f9")

        self.file_path = None
        tk.Label(root, text="RR Interval Analyzer", font=("Helvetica", 20, "bold"), fg="#003366", bg="#f4f7f9").pack(pady=15)

        form = tk.Frame(root, bg="#f4f7f9")
        form.pack()
        tk.Label(form, text="Patient ID:", font=("Helvetica", 12), bg="#f4f7f9").grid(row=0, column=0, sticky="e")
        self.entry_id = tk.Entry(form, width=30)
        self.entry_id.grid(row=0, column=1)

        tk.Label(form, text="Patient Name:", font=("Helvetica", 12), bg="#f4f7f9").grid(row=1, column=0, sticky="e")
        self.entry_name = tk.Entry(form, width=30)
        self.entry_name.grid(row=1, column=1)

        tk.Button(root, text="Upload RR Interval File", command=self.upload_file,
                  font=("Helvetica", 12), bg="#0055a5", fg="white").pack(pady=10)

        tk.Button(root, text="Analyze", command=self.analyze,
                  font=("Helvetica", 14, "bold"), bg="#28a745", fg="white").pack(pady=10)

        self.plot_frame = tk.Frame(root, bg="#f4f7f9")
        self.plot_frame.pack(pady=10, fill="both", expand=True)

    def upload_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if self.file_path:
            messagebox.showinfo("File Upload", f"File loaded:\n{self.file_path}")

    def analyze(self):
        try:
            df = pd.read_csv(self.file_path, sep='\t')
            rr_intervals = df['Pulse Interval (ms)'].values
            features = calculate_hrv_features(rr_intervals)

            patient_id = self.entry_id.get().strip()
            patient_name = self.entry_name.get().strip().replace(" ", "_")
            filename = f"{patient_id}_{patient_name}_rr.txt"

            with open(filename, "w") as f:
                f.write("RR Interval Analysis Results\n")
                f.write(f"Patient ID: {patient_id}\n")
                f.write(f"Patient Name: {patient_name.replace('_', ' ')}\n\n")
                for key, val in features.items():
                    f.write(f"{key}: {val:.3f}\n")

            messagebox.showinfo("Saved", f"Results saved to {filename}")

            for widget in self.plot_frame.winfo_children():
                widget.destroy()

            fig, ax = plt.subplots(figsize=(7, 3), dpi=100)
            ax.plot(df['Time (s)'].values, df['Pulse Interval (ms)'].values, color='blue')
            ax.set_title("RR Interval Time Series")
            ax.set_xlabel("Time (s)")
            ax.set_ylabel("Pulse Interval (ms)")
            fig.tight_layout()

            canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
            canvas.draw()
            canvas_widget = canvas.get_tk_widget()
            canvas_widget.pack(fill="both", expand=True)

            toolbar_frame = tk.Frame(self.plot_frame)
            toolbar_frame.pack(side="bottom", fill="x")
            toolbar = NavigationToolbar2Tk(canvas, toolbar_frame)
            toolbar.update()

        except Exception as e:
            messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    root = tk.Tk()
    app = RRAnalyzerApp(root)
    root.mainloop()