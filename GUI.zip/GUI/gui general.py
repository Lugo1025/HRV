import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import pandas as pd
import os
import joblib
import tensorflow as tf
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from scipy.signal import welch
from numpy.lib.stride_tricks import sliding_window_view
import pyhrv.tools as tools
import pyhrv.time_domain as td
import pyhrv.frequency_domain as fd
import pyhrv.nonlinear as nl

# ------------------------------- Models & Config -------------------------------
MODEL_DIR = "models"

model_options = {
    "Correlation (Top 15)": "Correlation_Top_15",
    "Correlation (Top 5)": "Correlation_Top_5",
    "Random Forest (Top 15)": "Random_Forest_Top_15",
    "Mutual Info (Top 15)": "Mutual_Info_Top_15"
}

logistic_configs = {
    "Correlation (Top 15)": {"intercept": -1.56, "coefficients": [0.9935, -0.8616, -0.3997, 0.4176, 1.3032, 0.6154, -1.0923, -0.7660, 0.0339, 0.5334, -0.3454, 0.2803, -1.2534, -0.0580, -0.0356]},
    "Correlation (Top 5)": {"intercept": -0.98, "coefficients": [0.6911, -0.7299, -0.4806, 0.3434, 0.4582]},
    "Random Forest (Top 15)": {"intercept": -2.13, "coefficients": [-0.8802, 0.0126, -0.1310, 0.5466, 0.7636, -0.3909, 0.5237, -0.0725, -0.0957, 4.2304, -0.0993, -0.2375, 0.2987, -3.9837, 0.2913]},
    "Mutual Info (Top 15)": {"intercept": -4.76, "coefficients": [0.6242, -0.8800, 0.3398, 0.8169, -4.1321, -0.1551, 0.6996, 316.9673, -0.0772, 0.3284, -11.0592, 0.1891, -8.0655, 1.8160, 0.9937]}
}

# ------------------------------- Utility Functions -------------------------------
def load_ann_model(model_key):
    prefix = model_options[model_key]
    model = tf.keras.models.load_model(os.path.join(MODEL_DIR, f"{prefix}_model.h5"))
    scaler = joblib.load(os.path.join(MODEL_DIR, f"{prefix}_scaler.pkl"))
    with open(os.path.join(MODEL_DIR, f"{prefix}_features.txt"), "r") as f:
        features = [line.strip() for line in f.readlines()]
    return model, scaler, features

def predict_ann(file_path, model, scaler, feature_order):
    with open(file_path, "r") as f:
        values = list(map(float, f.read().strip().split()))
    x = np.array(values).reshape(1, -1)
    x_scaled = scaler.transform(x)
    prob = model.predict(x_scaled).ravel()[0]
    label = "Alive (0)" if prob < 0.5 else "Dead (1)"
    return label, prob, values

def predict_logistic(values, model_key):
    config = logistic_configs[model_key]
    intercept = config["intercept"]
    coefs = np.array(config["coefficients"])
    logit = intercept + np.dot(coefs, values)
    prob = 1 / (1 + np.exp(-logit))
    return prob

def analyze_rr_file(rr_path, output_txt):
    try:
        # Try reading as tab-separated first
        try:
            df = pd.read_csv(rr_path, sep="\t")
        except:
            # Fall back to space-separated
            df = pd.read_csv(rr_path, sep="\s+", engine='python')
        
        # Check for required columns
        time_col = next((col for col in df.columns if 'time' in col.lower()), None)
        rr_col = next((col for col in df.columns if 'pulse' in col.lower() or 'rr' in col.lower() or 'interval' in col.lower()), None)
        
        if not time_col or not rr_col:
            raise ValueError("Input file must contain time and RR interval columns")
            
        rr_intervals = df[rr_col].values
        time_points = df[time_col].values
        
        rr_intervals = tools.check_input(rr_intervals)
        time_results = td.time_domain(rr_intervals)
        freq_results = fd.welch_psd(rr_intervals)
        nonlinear_results = nl.nonlinear(rr_intervals)

        with open(output_txt, "w") as f:
            f.write("HRV Features Extracted from RR Intervals\n")
            f.write("\nTime Domain:\n")
            for key, value in time_results.items():
                f.write(f"{key}: {value}\n")
            f.write("\nFrequency Domain:\n")
            for key, value in freq_results.items():
                f.write(f"{key}: {value}\n")
            f.write("\nNonlinear Measures:\n")
            for key, value in nonlinear_results.items():
                f.write(f"{key}: {value}\n")

        return df, time_col, rr_col
    except Exception as e:
        raise ValueError(f"Error processing RR file: {str(e)}")

# ------------------------------- GUI Classes -------------------------------
class ICUApp(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.file_path = None
        self.rr_path = None
        self.canvas = None
        self.toolbar = None
        self.build_ui()

    def build_ui(self):
        tk.Label(self, text="ICU Survival Prediction", font=("Helvetica", 24, "bold"), fg="#003366").pack(pady=15)
        form = tk.Frame(self)
        form.pack()
        tk.Label(form, text="Patient ID:", font=("Helvetica", 12)).grid(row=0, column=0, sticky="e")
        self.id_entry = tk.Entry(form, width=30)
        self.id_entry.grid(row=0, column=1)
        tk.Label(form, text="Patient Name:", font=("Helvetica", 12)).grid(row=1, column=0, sticky="e")
        self.name_entry = tk.Entry(form, width=30)
        self.name_entry.grid(row=1, column=1)
        tk.Label(form, text="Model:", font=("Helvetica", 12)).grid(row=2, column=0, sticky="e")
        self.model_var = tk.StringVar()
        model_dropdown = ttk.Combobox(form, textvariable=self.model_var, values=list(model_options.keys()), state="readonly", width=28)
        model_dropdown.grid(row=2, column=1)
        model_dropdown.set("Correlation (Top 15)")

        tk.Button(self, text="Upload Clinical File (.txt)", command=self.upload_clinical_file).pack(pady=5)
        tk.Button(self, text="Upload RR File (.txt)", command=self.upload_rr_file).pack(pady=5)
        tk.Button(self, text="Analyze", command=self.analyze).pack(pady=10)
        self.result_label = tk.Label(self, text="", font=("Helvetica", 14), fg="darkred")
        self.result_label.pack()
        self.log_label = tk.Label(self, text="", font=("Helvetica", 14), fg="darkblue")
        self.log_label.pack()

    def upload_clinical_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        messagebox.showinfo("File Upload", "Clinical variable file loaded.")

    def upload_rr_file(self):
        self.rr_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if self.rr_path:
            try:
                patient_id = self.id_entry.get().strip()
                patient_name = self.name_entry.get().strip().replace(" ", "_")
                rr_out = f"{patient_id}_{patient_name}_rr.txt"
                
                # Clear previous plot if exists
                if self.canvas:
                    self.canvas.get_tk_widget().destroy()
                    self.toolbar.destroy()
                
                # Analyze and plot
                df_rr, time_col, rr_col = analyze_rr_file(self.rr_path, rr_out)

                # Create plot
                fig, ax = plt.subplots(figsize=(7, 3))
                ax.plot(df_rr[time_col], df_rr[rr_col])
                ax.set_title("RR Interval Time Series")
                ax.set_xlabel(time_col)
                ax.set_ylabel(rr_col)
                
                # Embed plot in GUI
                self.canvas = FigureCanvasTkAgg(fig, master=self)
                self.canvas.draw()
                self.canvas.get_tk_widget().pack(pady=10)
                
                # Add toolbar
                self.toolbar = NavigationToolbar2Tk(self.canvas, self)
                self.toolbar.update()
                self.canvas.get_tk_widget().pack()

                messagebox.showinfo("RR Analysis", f"RR interval analysis saved to:\n{rr_out}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to process RR file: {str(e)}")

    def analyze(self):
        try:
            if not self.file_path:
                raise ValueError("Please upload a clinical file first")
                
            model_key = self.model_var.get()
            patient_name = self.name_entry.get().strip().replace(" ", "_")
            patient_id = self.id_entry.get().strip()
            model, scaler, features = load_ann_model(model_key)
            label, ann_prob, values = predict_ann(self.file_path, model, scaler, features)
            log_prob = predict_logistic(values, model_key)

            self.result_label.config(text=f"ANN Prediction: {label} (Survival Probability: {ann_prob*100:.2f}%)")
        except Exception as e:
            messagebox.showerror("Error", str(e))

class RRAnalyzerApp(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.file_path = None
        self.canvas = None
        self.toolbar = None
        self.build_ui()

    def build_ui(self):
        tk.Label(self, text="RR Interval Analyzer", font=("Helvetica", 20, "bold")).pack(pady=15)
        form = tk.Frame(self)
        form.pack()
        tk.Label(form, text="Patient ID:", font=("Helvetica", 12)).grid(row=0, column=0)
        self.entry_id = tk.Entry(form, width=30)
        self.entry_id.grid(row=0, column=1)
        tk.Label(form, text="Patient Name:", font=("Helvetica", 12)).grid(row=1, column=0)
        self.entry_name = tk.Entry(form, width=30)
        self.entry_name.grid(row=1, column=1)
        tk.Button(self, text="Upload RR Interval File", command=self.upload_file).pack(pady=5)
        tk.Button(self, text="Analyze", command=self.analyze).pack(pady=5)
        self.plot_frame = tk.Frame(self)
        self.plot_frame.pack(pady=10, fill="both", expand=True)

    def upload_file(self):
        self.file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if self.file_path:
            messagebox.showinfo("File Upload", f"File loaded:\n{self.file_path}")

    def analyze(self):
        try:
            if not self.file_path:
                raise ValueError("Please upload an RR interval file first")
                
            # Try reading as tab-separated first
            try:
                df = pd.read_csv(self.file_path, sep="\t")
            except:
                # Fall back to space-separated
                df = pd.read_csv(self.file_path, sep="\s+", engine='python')
            
            # Check for required columns
            time_col = next((col for col in df.columns if 'time' in col.lower()), None)
            rr_col = next((col for col in df.columns if 'pulse' in col.lower() or 'rr' in col.lower() or 'interval' in col.lower()), None)
            
            if not time_col or not rr_col:
                raise ValueError("Input file must contain time and RR interval columns")
                
            patient_id = self.entry_id.get().strip()
            patient_name = self.entry_name.get().strip().replace(" ", "_")
            filename = f"{patient_id}_{patient_name}_rr.txt"

            rr_intervals = df[rr_col].values
            rr_intervals = tools.check_input(rr_intervals)
            
            time_results = td.time_domain(rr_intervals)
            freq_results = fd.welch_psd(rr_intervals)
            nonlinear_results = nl.nonlinear(rr_intervals)

            with open(filename, "w") as f:
                f.write(f"Patient ID: {patient_id}\nPatient Name: {patient_name}\n\n")
                f.write("Time Domain:\n")
                for k, v in time_results.items():
                    f.write(f"{k}: {v}\n")
                f.write("\nFrequency Domain:\n")
                for k, v in freq_results.items():
                    f.write(f"{k}: {v}\n")
                f.write("\nNonlinear Measures:\n")
                for k, v in nonlinear_results.items():
                    f.write(f"{k}: {v}\n")

            # Clear previous plot if exists
            for widget in self.plot_frame.winfo_children():
                widget.destroy()

            # Create new plot
            fig, ax = plt.subplots(figsize=(7, 3))
            ax.plot(df[time_col], df[rr_col], color="blue")
            ax.set_title("RR Interval Time Series")
            ax.set_xlabel(time_col)
            ax.set_ylabel(rr_col)
            
            # Embed plot in GUI
            canvas = FigureCanvasTkAgg(fig, master=self.plot_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)
            
            # Add toolbar
            toolbar = NavigationToolbar2Tk(canvas, self.plot_frame)
            toolbar.update()
            
        except Exception as e:
            messagebox.showerror("Error", str(e))

# ------------------------------- Main App Runner -------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.title("ICU Survival & RR Interval Analyzer")
    root.geometry("1024x860")
    notebook = ttk.Notebook(root)
    notebook.pack(expand=1, fill="both")

    tab1 = ICUApp(notebook)
    tab2 = RRAnalyzerApp(notebook)
    notebook.add(tab1, text="ICU Prediction")
    notebook.add(tab2, text="RR Interval Analyzer")

    root.mainloop()